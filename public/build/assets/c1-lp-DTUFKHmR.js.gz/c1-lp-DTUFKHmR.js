const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/c1-lp-below-BlWfejmg.js","assets/react-vendor-B7UWnm2f.js","assets/rolldown-runtime-tcWNtVWY.js"])))=>i.map(i=>d[i]);
import{n as e,r as t}from"./rolldown-runtime-tcWNtVWY.js";import{t as n}from"./preload-helper-DeSptEav.js";import{a as r,t as i}from"./react-vendor-B7UWnm2f.js";var a=e({default:()=>d}),o=t(r(),1),s=i(),c=(0,o.lazy)(()=>n(()=>import(`./c1-lp-below-BlWfejmg.js`),__vite__mapDeps([0,1,2]))),l=String.raw`:root {
  --brand: #273B6A;
  --brand-700: #1f2f55;
  --brand-800: #17233f;
  --brand-900: #0f1a30;
  --brand-100: #eef1f7;
  --brand-200: #dbe2ee;
  --cta: #70CE73;
  --cta-dark: #4fae55;
  --star: #FFC107;
  --ink: #17233f;
  --body: #48536b;
  --line: #e2e6ee;
  --wash: #f6f8fc;
}
*, *::before, *::after { box-sizing: border-box; }
html { scroll-behavior: smooth; scroll-padding-top: 86px; }
body { margin: 0; background: #FFFFFF; font-family: "Montserrat", system-ui, sans-serif; color: var(--ink); }
img { display: block; max-width: 100%; }
.hero-review-avatars { flex: none; min-width: 56px; }
.hero-review-avatar {
  width: 24px !important;
  min-width: 24px !important;
  max-width: 24px !important;
  height: 24px !important;
  min-height: 24px !important;
  max-height: 24px !important;
  aspect-ratio: 1 / 1;
  object-fit: cover;
  flex: none;
}
a { color: var(--brand); }
a:hover { color: var(--brand-700); }
h1, h2, h3, h4 { font-family: "Montserrat", system-ui, sans-serif; font-weight: 800; line-height: 1.14; margin: 0; letter-spacing: -0.01em; }
p { margin: 0; line-height: 1.65; }
ul { margin: 0; }
[data-lg="id"] [data-l="en"], [data-lg="en"] [data-l="id"] { display: none !important; }
summary { list-style: none; }
summary::-webkit-details-marker { display: none; }
details[open] .plus { transform: rotate(45deg); }
.cta { display: inline-flex; align-items: center; justify-content: center; gap: 10px; background: var(--cta); color: #FFFFFF; font-family: "Montserrat", sans-serif; font-weight: 800; font-size: 15px; letter-spacing: 0.01em; padding: 15px 26px; border-radius: 8px; text-decoration: none; box-shadow: 0 6px 18px rgba(79, 174, 85, 0.28); transition: background 0.15s ease, transform 0.15s ease; }
.cta:hover { background: var(--cta-dark); color: #FFFFFF; transform: translateY(-1px); }
.cta:focus-visible { outline: 3px solid var(--brand); outline-offset: 3px; }
.micro { display: flex; flex-wrap: wrap; align-items: center; gap: 6px 10px; font-size: 12px; font-weight: 600; color: var(--body); }
.micro .st { color: var(--star); letter-spacing: 1px; }
.kicker { font-family: "Montserrat", sans-serif; font-weight: 800; font-size: 11px; letter-spacing: 0.16em; text-transform: uppercase; color: var(--brand); }
.sec { padding: 84px 24px; }
.wrap { max-width: 1160px; margin: 0 auto; }
.card { background: #FFFFFF; border: 1px solid var(--line); border-radius: 14px; padding: 26px; box-shadow: 0 2px 10px rgba(23, 35, 63, 0.05); }
#page > header { position: sticky !important; top: 0 !important; z-index: 70 !important; }
#page > section:not(#top), #page > div, #page > footer {
  content-visibility: auto;
  contain-intrinsic-size: auto 900px;
}
@media (max-width: 760px) {
  .rev-grid[data-collapsed="1"] > figure:nth-child(n + 4) { display: none !important; }
  .rev-more { display: flex !important; }
}
.photo-grid img { height: auto !important; }
.rev-grid > figure { background: #F5F5F8 !important; }
.rev-grid figcaption img { background: #d7dbe3 !important; }
.wa-popup {
  position: fixed;
  right: 18px;
  bottom: 92px;
  z-index: 81;
  width: min(320px, calc(100vw - 36px));
  display: grid;
  grid-template-columns: 48px minmax(0, 1fr);
  gap: 12px;
  align-items: start;
  padding: 18px 20px 16px;
  background: #FFFFFF;
  border: 1px solid rgba(39, 59, 106, 0.1);
  border-radius: 14px;
  box-shadow: 0 16px 42px rgba(15, 26, 48, 0.28);
  animation: wa-popup-in 0.3s ease-out;
}
.wa-popup-logo { width: 48px; height: 48px; object-fit: contain; }
.wa-popup-title { display: block; padding-right: 22px; color: var(--ink); font-size: 15px; line-height: 1.3; }
.wa-popup-copy { margin-top: 4px; color: var(--body); font-size: 14px; line-height: 1.4; }
.wa-popup-link { display: inline-flex; margin-top: 10px; color: var(--cta-dark); font-size: 14px; font-weight: 800; text-decoration: none; }
.wa-popup-link:hover { color: #3f9145; }
.wa-popup-close {
  position: absolute;
  top: -10px;
  right: -8px;
  width: 28px;
  height: 28px;
  border: 0;
  border-radius: 50%;
  background: var(--brand-900);
  color: #FFFFFF;
  font-size: 18px;
  line-height: 1;
  cursor: pointer;
  box-shadow: 0 5px 14px rgba(15, 26, 48, 0.25);
}
.wa-popup-close:focus-visible { outline: 3px solid var(--cta); outline-offset: 2px; }
@keyframes wa-popup-in {
  from { opacity: 0; transform: translateY(12px) scale(0.98); }
  to { opacity: 1; transform: translateY(0) scale(1); }
}
@media (max-width: 900px) {
  .sec { padding: 56px 18px; }
  #page > header { position: fixed !important; top: 0 !important; left: 0 !important; right: 0 !important; width: 100% !important; z-index: 90 !important; }
  #page { padding-top: 62px !important; }
  #page > header > div { padding: 8px 12px !important; gap: 8px !important; }
  #page > header img { height: 34px !important; }
  #page > header a[href*="wa.me"] { padding: 9px 12px !important; font-size: 11px !important; box-shadow: none !important; }
  #page > header a[href*="wa.me"] span { display: none !important; }
  #page > header a[href*="wa.me"]::after { content: "Book now"; font-weight: 800; }
  #page > header button { padding: 7px 9px !important; font-size: 11px !important; }
  .cmp thead th:first-child, .cmp tbody th { font-size: 12px !important; }
  #snorkeling, #scuba-diving, #try-scuba { grid-template-columns: 1fr !important; }
  #snorkeling > div:first-child, #try-scuba > div:first-child, #scuba-diving > div:last-child { min-height: 260px !important; }
  #top { min-height: calc(100svh - 62px) !important; }
  #hero-img { object-position: 62% 40% !important; }
  h1 { font-size: 27px !important; }
  h2 { font-size: 24px !important; }
  #page section .cta, #page footer .cta { width: 100% !important; }
  .micro { font-size: 11px !important; }
  .cmp th, .cmp td { padding: 10px 8px !important; }
  .photo-grid { grid-template-columns: repeat(2, 1fr) !important; }
  .wa-popup {
    right: 12px;
    bottom: 74px;
    width: 280px;
    grid-template-columns: 40px minmax(0, 1fr);
    gap: 10px;
    padding: 14px 16px;
    border-radius: 14px;
  }
  .wa-popup-logo { width: 40px; height: 40px; }
  .wa-popup-title { padding-right: 14px; font-size: 13px; }
  .wa-popup-copy { margin-top: 3px; font-size: 12px; line-height: 1.4; }
  .wa-popup-link { margin-top: 8px; font-size: 13px; }
  .wa-popup-close { top: -11px; right: -5px; width: 30px; height: 30px; font-size: 19px; }
  .wa-floating-button { right: 12px !important; bottom: 12px !important; width: 50px !important; height: 50px !important; }
  .wa-floating-button svg { width: 26px !important; height: 26px !important; }
}
@media (prefers-reduced-motion: reduce) {
  .wa-popup { animation: none; }
}`,u=e=>({cursor:`pointer`,border:0,padding:`8px 12px`,fontSize:`12px`,fontFamily:`Montserrat, sans-serif`,fontWeight:800,letterSpacing:`0.04em`,background:e?`#273B6A`:`transparent`,color:e?`#FFFFFF`:`#48536b`});function d(){let[e,t]=(0,o.useState)(`en`),[r,i]=(0,o.useState)(!1),[a,d]=(0,o.useState)(!1);return(0,o.useEffect)(()=>{!document.querySelector(`script[src*="googletagmanager.com/gtm.js?id=GTM-PP3LHJ7F"]`)&&!window.__gtmLoaded&&(window.__gtmLoaded=!0,(function(e,t,n,r,i){e[r]=e[r]||[],e[r].push({"gtm.start":new Date().getTime(),event:`gtm.js`});var a=t.getElementsByTagName(n)[0],o=t.createElement(n),s=r===`dataLayer`?``:`&l=`+r;o.async=!0,o.src=`https://www.googletagmanager.com/gtm.js?id=`+i+s;let c=t.querySelector(`[nonce]`);c&&o.setAttribute(`nonce`,c.nonce||c.getAttribute(`nonce`)||``),a.parentNode?.insertBefore(o,a)})(window,document,`script`,`dataLayer`,`GTM-PP3LHJ7F`))},[]),(0,o.useEffect)(()=>{let e,t=window.setTimeout(()=>{n(()=>import(`./c1-lp-below-BlWfejmg.js`),__vite__mapDeps([0,1,2])),e=`requestIdleCallback`in window?window.requestIdleCallback(()=>i(!0),{timeout:2e3}):setTimeout(()=>i(!0),250)},100);return()=>{window.clearTimeout(t),e!==void 0&&(`cancelIdleCallback`in window?window.cancelIdleCallback(e):clearTimeout(e))}},[]),(0,o.useEffect)(()=>{let e=window.setTimeout(()=>{d(!0)},1e4);return()=>window.clearTimeout(e)},[]),(0,o.useEffect)(()=>{let e=window.location.pathname,t=new URLSearchParams(window.location.search),n=`landing_source`,r=`referral_source`,i=[25,50,75,90],a=e=>{try{return sessionStorage.getItem(e)}catch{return null}},o=(e,t)=>{try{sessionStorage.setItem(e,t)}catch{}};if(a(n)||o(n,e),!a(r)){let e=t.get(`ref`)||`direct`;if(document.referrer)try{new URL(document.referrer).hostname!==window.location.hostname&&(e=document.referrer)}catch{}o(r,e)}let s=`ab_variant_c1lp`;a(s)||o(s,Math.random()<.5?`A`:`B`),window.__abVariant=a(s);let c=e=>e+`-`+(crypto.randomUUID?.()??Date.now()+`-`+Math.random().toString(36).slice(2,11)),l=e=>{let t=document.cookie.match(RegExp(`(?:^|; )`+e+`=([^;]*)`));return t?decodeURIComponent(t[1]):null},u=(i,o={},s=!1)=>{let c=document.querySelector(`meta[name="csrf-token"]`)?.content,l=JSON.stringify({event_type:i,event_data:Object.assign({landing_source:a(n)||e,page:e,timestamp:new Date().toISOString()},o),referral_source:a(r)||`direct`,utm_source:t.get(`utm_source`),utm_medium:t.get(`utm_medium`),utm_campaign:t.get(`utm_campaign`),utm_content:t.get(`utm_content`),utm_term:t.get(`utm_term`)});return s&&navigator.sendBeacon?navigator.sendBeacon(`/analytics/track`,new Blob([l],{type:`application/json`})):(fetch(`/analytics/track`,{method:`POST`,credentials:`same-origin`,keepalive:!0,headers:{"Content-Type":`application/json`,...c?{"X-CSRF-TOKEN":c}:{}},body:l}).catch(()=>{}),!0)},d=()=>{let t=`analytics_visit_tracked:`+(a(n)||e);a(t)||u(`visit`,{event_id:c(`page-view`),is_initial:!0,_fbp:l(`_fbp`),_fbc:l(`_fbc`),ab_variant:a(s)},!0)&&o(t,`1`)},f=()=>{let t=document.documentElement.scrollHeight-window.innerHeight;if(t<=0)return;let n=Math.round(window.scrollY/t*100);i.forEach(t=>{let r=`analytics_scroll:`+e+`:`+t;n>=t&&!a(r)&&(o(r,`1`),u(`scroll`,{depth:t}))})},p=()=>{let e=0,t=!1,n=0;return window.setInterval(()=>{if(!document.hidden){if(e+=1e3,!t&&e>=15e3){t=!0,n=0,u(`engagement`,{type:`dwell_ping`,duration:15e3,is_initial:!0});return}t&&++n>=30&&(n=0,u(`engagement`,{type:`dwell_ping`,duration:3e4,is_initial:!1}))}},1e3)},m=null,h=()=>{if(!(`IntersectionObserver`in window))return;let t=new Map;m=new IntersectionObserver(n=>{n.forEach(n=>{let r=n.target,i=`section_seen_v2_`+e+`:`+r.id;if(!n.isIntersecting){t.has(r.id)&&window.clearTimeout(t.get(r.id)),t.delete(r.id);return}a(i)||t.has(r.id)||t.set(r.id,window.setTimeout(()=>{t.delete(r.id),!a(i)&&(o(i,`1`),u(`section_view`,{section:r.id}),m?.unobserve(r))},500))})},{threshold:.2}),document.querySelectorAll(`section[id]`).forEach(e=>m.observe(e))},g=e=>{let t=e.target.closest(`a`);if(!t)return;let n=(t.textContent||t.getAttribute(`aria-label`)||`CTA`).replace(/\s+/g,` `).trim().slice(0,255);if(t.href.includes(`wa.me/`)){let e=t.href,r=decodeURIComponent(e.replace(/\+/g,` `)).toLowerCase(),i=t.closest(`section[id]`),o=t.getAttribute(`aria-label`)===`Chat on WhatsApp`?`floating_whatsapp`:i?i.id:t.closest(`header`)?`header`:`footer`,d=null;r.includes(`try scuba`)?d=`Try Scuba Diving`:r.includes(`scuba`)?d=`Scuba Diving`:r.includes(`snorkel`)&&(d=`Snorkeling`);let f=c(`wa`),p=d?`wa_registration`:`wa_inquiry`,m={location:o,text:n,destination:e,package:d,_fbp:l(`_fbp`),_fbc:l(`_fbc`),ab_variant:a(s)};u(`cta_click`,{event_id:c(`cta`),...m},!0),u(`conversion`,{event_id:f,type:p,meta_event:`Search`,...m},!0),typeof window.fbq==`function`&&window.fbq(`track`,`Search`,{content_category:p,content_name:d||`WhatsApp inquiry`},{eventID:f})}};document.addEventListener(`click`,g);let _=e=>{`requestIdleCallback`in window?window.requestIdleCallback(e,{timeout:3e3}):setTimeout(e,1500)},v,y=()=>{_(d),f(),v=p(),h()};document.readyState===`complete`?y():window.addEventListener(`load`,y,{once:!0});let b=()=>f();return window.addEventListener(`scroll`,b,{passive:!0}),()=>{document.removeEventListener(`click`,g),window.removeEventListener(`scroll`,b),v!==void 0&&window.clearInterval(v),m?.disconnect()}},[]),(0,s.jsxs)(s.Fragment,{children:[(0,s.jsxs)(s.Fragment,{children:[(0,s.jsx)(`title`,{children:`Menjangan Snorkeling Trip & Diving`}),(0,s.jsx)(`meta`,{name:`description`,content:`Snorkeling and scuba diving trips at Menjangan Island, West Bali. Half-day trips including equipment, park permit, guide, and lunch. Book direct — best price guaranteed.`}),(0,s.jsx)(`link`,{rel:`canonical`,href:`https://menjanganislandtrip.com/c1-lp`}),(0,s.jsx)(`meta`,{name:`robots`,content:`index, follow`}),(0,s.jsx)(`meta`,{property:`og:type`,content:`website`}),(0,s.jsx)(`meta`,{property:`og:title`,content:`Menjangan Island Snorkeling Trip & Diving — Bali`}),(0,s.jsx)(`meta`,{property:`og:description`,content:`Half-day snorkeling and diving trips at Menjangan Island, West Bali. Equipment, guide, park permit, and lunch included. Book direct — best price guaranteed.`}),(0,s.jsx)(`meta`,{property:`og:url`,content:`https://menjanganislandtrip.com/c1-lp`}),(0,s.jsx)(`meta`,{property:`og:image`,content:`https://menjanganislandtrip.com/c1/hero-reef-diver.webp`}),(0,s.jsx)(`meta`,{property:`og:image:width`,content:`1400`}),(0,s.jsx)(`meta`,{property:`og:image:height`,content:`933`}),(0,s.jsx)(`meta`,{property:`og:locale`,content:`en_US`}),(0,s.jsx)(`meta`,{property:`og:locale:alternate`,content:`id_ID`}),(0,s.jsx)(`meta`,{property:`og:site_name`,content:`Menjangan Snorkeling Trip & Diving`}),(0,s.jsx)(`meta`,{name:`twitter:card`,content:`summary_large_image`}),(0,s.jsx)(`meta`,{name:`twitter:title`,content:`Menjangan Island Snorkeling & Diving — West Bali`}),(0,s.jsx)(`meta`,{name:`twitter:description`,content:`Half-day snorkeling and diving trips at Menjangan Island, West Bali. Equipment, guide, park permit, and lunch included.`}),(0,s.jsx)(`meta`,{name:`twitter:image`,content:`https://menjanganislandtrip.com/c1/hero-reef-diver.webp`}),(0,s.jsx)(`link`,{rel:`alternate`,hrefLang:`en`,href:`https://menjanganislandtrip.com/c1-lp`}),(0,s.jsx)(`link`,{rel:`alternate`,hrefLang:`id`,href:`https://menjanganislandtrip.com/c1-lp`}),(0,s.jsx)(`link`,{rel:`alternate`,hrefLang:`x-default`,href:`https://menjanganislandtrip.com/c1-lp`}),(0,s.jsx)(`link`,{rel:`preload`,as:`image`,href:`/c1/hero-reef-diver-800.avif`,type:`image/avif`,imageSrcSet:`/c1/hero-reef-diver-480.avif 480w, /c1/hero-reef-diver-800.avif 800w, /c1/hero-reef-diver-1400.avif 1400w`,imageSizes:`100vw`}),(0,s.jsx)(`style`,{children:l})]}),(0,s.jsxs)(`div`,{id:`page`,"data-lg":e,children:[(0,s.jsx)(`noscript`,{children:(0,s.jsx)(`iframe`,{src:`https://www.googletagmanager.com/ns.html?id=GTM-PP3LHJ7F`,height:`0`,width:`0`,style:{display:`none`,visibility:`hidden`}})}),(0,s.jsx)(`header`,{style:{background:`#FFFFFF`,borderBottom:`1px solid var(--line)`,boxShadow:`0 1px 6px rgba(23, 35, 63, 0.07)`},children:(0,s.jsxs)(`div`,{style:{maxWidth:`1160px`,margin:`0 auto`,padding:`10px 24px`,display:`flex`,alignItems:`center`,gap:`14px`,flexWrap:`nowrap`},children:[(0,s.jsx)(`img`,{src:`/c1/logo-menjangan-128.webp`,alt:`Menjangan Snorkeling Trip and Diving`,width:52,height:52,style:{height:`52px`,width:`auto`,flex:`none`,marginRight:`auto`}}),(0,s.jsxs)(`div`,{style:{display:`flex`,alignItems:`center`,border:`1px solid var(--line)`,borderRadius:`6px`,overflow:`hidden`,flex:`none`},children:[(0,s.jsx)(`button`,{type:`button`,onClick:()=>t(`en`),style:u(e===`en`),children:`EN`}),(0,s.jsx)(`button`,{type:`button`,onClick:()=>t(`id`),style:u(e===`id`),children:`ID`})]}),(0,s.jsxs)(`a`,{className:`cta`,href:`https://wa.me/6281238578042?text=(uc)%20Hello%2C%20I%20would%20like%20to%20book%20a%20trip%20to%20Menjangan%20Island.`,target:`_blank`,rel:`noopener noreferrer`,"aria-label":`Book via WhatsApp`,style:{padding:`11px 18px`,fontSize:`13px`,flex:`none`},children:[(0,s.jsx)(`svg`,{viewBox:`0 0 24 24`,fill:`currentColor`,"aria-hidden":`true`,style:{width:`17px`,height:`17px`,flex:`none`},children:(0,s.jsx)(`path`,{d:`M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2 22l5.25-1.38a9.9 9.9 0 0 0 4.75 1.21h.01c5.46 0 9.91-4.45 9.91-9.91C21.92 6.45 17.5 2 12.04 2zm0 18.13c-1.5 0-2.96-.4-4.24-1.16l-.3-.18-3.15.83.84-3.07-.2-.32a8.16 8.16 0 0 1-1.25-4.32c0-4.54 3.7-8.23 8.24-8.23 2.2 0 4.27.86 5.82 2.41a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.21-8.17 8.21zm4.79-5.85c-.26-.13-1.55-.76-1.79-.85-.24-.09-.41-.13-.59.13-.17.26-.67.85-.83 1.02-.15.18-.3.19-.57.06-.26-.13-.99-.37-1.88-1.16-.7-.62-1.17-1.39-1.3-1.65-.13-.26-.02-.4.11-.53.13-.13.26-.3.4-.46.13-.15.17-.26.26-.44.09-.17.04-.33-.03-.46-.06-.13-.59-1.41-.8-1.93-.21-.5-.43-.44-.59-.45h-.5c-.17 0-.45.06-.69.32-.24.26-.91.88-.91 2.16s.93 2.51 1.06 2.69c.13.17 1.83 2.92 4.44 3.99.62.27 1.1.43 1.48.55.62.2 1.19.17 1.64.1.5-.07 1.54-.63 1.76-1.24.22-.61.22-1.13.15-1.24-.06-.11-.24-.18-.5-.31z`})}),(0,s.jsx)(`span`,{"data-l":`en`,children:`Book via WhatsApp`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Booking via WhatsApp`})]})]})}),(0,s.jsxs)(`section`,{id:`top`,style:{position:`relative`,minHeight:`min(74vh, 620px)`,display:`grid`,alignItems:`center`,overflow:`hidden`},children:[(0,s.jsxs)(`picture`,{style:{position:`absolute`,inset:`0`},children:[(0,s.jsx)(`source`,{type:`image/avif`,srcSet:`/c1/hero-reef-diver-480.avif 480w, /c1/hero-reef-diver-800.avif 800w, /c1/hero-reef-diver-1400.avif 1400w`,sizes:`100vw`}),(0,s.jsx)(`source`,{type:`image/webp`,srcSet:`/c1/hero-reef-diver-480.webp 480w, /c1/hero-reef-diver-800.webp 800w, /c1/hero-reef-diver.webp 1400w`,sizes:`100vw`}),(0,s.jsx)(`img`,{id:`hero-img`,src:`/c1/hero-reef-diver-800.webp`,alt:`Snorkeler gliding over coral and sea fans at Menjangan Island`,width:1400,height:933,fetchPriority:`high`,loading:`eager`,style:{position:`absolute`,inset:`0`,width:`100%`,height:`100%`,objectFit:`cover`,objectPosition:`58% 42%`}})]}),(0,s.jsx)(`div`,{style:{position:`absolute`,inset:`0`,background:`linear-gradient(180deg, rgba(15, 26, 48, 0.52) 0%, rgba(15, 26, 48, 0.18) 34%, rgba(15, 26, 48, 0.74) 74%, rgba(15, 26, 48, 0.92) 100%)`}}),(0,s.jsxs)(`div`,{style:{position:`relative`,maxWidth:`1160px`,width:`100%`,margin:`0 auto`,padding:`60px 24px 40px`,color:`#FFFFFF`},children:[(0,s.jsxs)(`div`,{style:{display:`inline-flex`,alignItems:`center`,gap:`10px`,border:`1px solid rgba(255, 255, 255, 0.5)`,borderRadius:`999px`,padding:`5px 12px`,marginBottom:`14px`},children:[(0,s.jsx)(`span`,{style:{color:`var(--star)`,fontSize:`13px`,letterSpacing:`1px`},children:`★★★★★`}),(0,s.jsxs)(`span`,{style:{fontWeight:`800`,fontSize:`11px`,letterSpacing:`0.1em`,textTransform:`uppercase`},children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`1.150+ five-star reviews`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`1.150+ ulasan bintang 5`})]}),(0,s.jsxs)(`span`,{className:`hero-review-avatars`,style:{display:`flex`,alignItems:`center`},children:[(0,s.jsx)(`img`,{className:`hero-review-avatar`,src:`https://lh3.googleusercontent.com/a-/ALV-UjW-6b9dWJYlqucqyOG9MKBwePsZDQk6FMk2lCZxhY9Z1lN2FcE=w80-h80-c-rp-mo-br100`,alt:``,width:24,height:24,decoding:`async`,style:{width:`24px`,height:`24px`,borderRadius:`50%`,border:`2px solid #ffffff`,objectFit:`cover`,flex:`none`}}),(0,s.jsx)(`img`,{className:`hero-review-avatar`,src:`https://lh3.googleusercontent.com/a-/ALV-UjUe8F2EkfzifVFcolV6LH52P7urkwIJt9u-9YQRxgiRzuqEgGSdQw=w80-h80-c-rp-mo-ba12-br100`,alt:``,width:24,height:24,decoding:`async`,style:{width:`24px`,height:`24px`,borderRadius:`50%`,border:`2px solid #ffffff`,objectFit:`cover`,flex:`none`,marginLeft:`-8px`}}),(0,s.jsx)(`img`,{className:`hero-review-avatar`,src:`https://lh3.googleusercontent.com/a-/ALV-UjWgkfdm69EosFB2aGTOvOG8fJAhDiDs-6kjQHwAfen3aB7WXMDY-g=w80-h80-c-rp-mo-br100`,alt:``,width:24,height:24,decoding:`async`,style:{width:`24px`,height:`24px`,borderRadius:`50%`,border:`2px solid #ffffff`,objectFit:`cover`,flex:`none`,marginLeft:`-8px`}})]})]}),(0,s.jsxs)(`h1`,{style:{fontSize:`clamp(27px, 4vw, 50px)`,color:`#FFFFFF`,maxWidth:`22ch`,marginBottom:`12px`,textShadow:`0 2px 18px rgba(15, 26, 48, 0.55)`},children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`Explore Best Snorkeling & Diving Spots at Menjangan Island`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Snorkeling & Diving di Pulau Menjangan`})]}),(0,s.jsxs)(`p`,{style:{maxWidth:`50ch`,fontSize:`15px`,color:`#FFFFFF`,textShadow:`0 1px 12px rgba(15, 26, 48, 0.5)`},children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`Float above turtles, marine life and coral gardens in the clearest water in Bali, with a trusted local team who knows the island.`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Jelajahi air yang jernih, terumbu karang yang hidup dan biota laut tropis bersama tim lokal terpercaya yang mengenal pulau ini.`})]}),(0,s.jsxs)(`div`,{style:{display:`grid`,justifyItems:`start`,gap:`10px`,margin:`20px 0 16px`},children:[(0,s.jsxs)(`a`,{className:`cta`,href:`#trips`,children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`View Trip Packages`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Lihat Pilihan Paket`})]}),(0,s.jsxs)(`span`,{className:`micro`,style:{color:`rgba(255, 255, 255, 0.92)`},children:[(0,s.jsx)(`span`,{className:`st`,children:`★★★★★`}),(0,s.jsxs)(`span`,{children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`5-star reviews · Insurance 100% · Licensed operator`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Ulasan bintang 5 · Asuransi 100% · Operator berlisensi`})]})]})]})]})]}),r&&(0,s.jsx)(o.Suspense,{fallback:null,children:(0,s.jsx)(c,{showMoreReviews:e=>{let t=e.currentTarget.dataset.more;t&&(document.getElementById(t)?.removeAttribute(`data-collapsed`),e.currentTarget.parentElement?.style.setProperty(`display`,`none`,`important`))}})}),a&&(0,s.jsxs)(`aside`,{className:`wa-popup`,role:`dialog`,"aria-label":`WhatsApp assistance`,children:[(0,s.jsx)(`button`,{className:`wa-popup-close`,type:`button`,"aria-label":`Close WhatsApp popup`,onClick:()=>d(!1),children:`×`}),(0,s.jsx)(`img`,{className:`wa-popup-logo`,src:`/c1/logo-menjangan-128.webp`,alt:``,width:58,height:58}),(0,s.jsxs)(`div`,{children:[(0,s.jsx)(`strong`,{className:`wa-popup-title`,children:`Menjangan Island Trip Team`}),(0,s.jsxs)(`p`,{className:`wa-popup-copy`,children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`Still deciding, or have a question? Ask me directly on WhatsApp.`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Masih mempertimbangkan atau punya pertanyaan? Tanya langsung melalui WhatsApp.`})]}),(0,s.jsxs)(`a`,{className:`wa-popup-link`,href:`https://wa.me/6281238578042?text=(uc)%20Hello%2C%20I%20have%20a%20question%20about%20a%20Menjangan%20Island%20trip.`,target:`_blank`,rel:`noopener noreferrer`,"aria-label":`Chat on WhatsApp`,onClick:()=>d(!1),children:[(0,s.jsx)(`span`,{"data-l":`en`,children:`Reply now\xA0→`}),(0,s.jsx)(`span`,{"data-l":`id`,children:`Balas sekarang\xA0→`})]})]})]}),(0,s.jsx)(`a`,{className:`wa-floating-button`,href:`https://wa.me/6281238578042?text=(uc)%20Hello%2C%20I%20would%20like%20to%20book%20a%20trip%20to%20Menjangan%20Island.`,target:`_blank`,rel:`noopener noreferrer`,"aria-label":`Chat on WhatsApp`,style:{position:`fixed`,right:`18px`,bottom:`18px`,zIndex:`80`,width:`58px`,height:`58px`,borderRadius:`50%`,background:`var(--cta)`,color:`#FFFFFF`,display:`grid`,placeItems:`center`,boxShadow:`0 8px 22px rgba(15, 26, 48, 0.28)`,textDecoration:`none`},children:(0,s.jsx)(`svg`,{viewBox:`0 0 24 24`,fill:`currentColor`,"aria-hidden":`true`,style:{width:`30px`,height:`30px`},children:(0,s.jsx)(`path`,{d:`M12.04 2C6.58 2 2.13 6.45 2.13 11.91c0 1.75.46 3.46 1.32 4.96L2 22l5.25-1.38a9.9 9.9 0 0 0 4.75 1.21h.01c5.46 0 9.91-4.45 9.91-9.91C21.92 6.45 17.5 2 12.04 2zm0 18.13c-1.5 0-2.96-.4-4.24-1.16l-.3-.18-3.15.83.84-3.07-.2-.32a8.16 8.16 0 0 1-1.25-4.32c0-4.54 3.7-8.23 8.24-8.23 2.2 0 4.27.86 5.82 2.41a8.18 8.18 0 0 1 2.41 5.83c0 4.54-3.7 8.21-8.17 8.21zm4.79-5.85c-.26-.13-1.55-.76-1.79-.85-.24-.09-.41-.13-.59.13-.17.26-.67.85-.83 1.02-.15.18-.3.19-.57.06-.26-.13-.99-.37-1.88-1.16-.7-.62-1.17-1.39-1.3-1.65-.13-.26-.02-.4.11-.53.13-.13.26-.3.4-.46.13-.15.17-.26.26-.44.09-.17.04-.33-.03-.46-.06-.13-.59-1.41-.8-1.93-.21-.5-.43-.44-.59-.45h-.5c-.17 0-.45.06-.69.32-.24.26-.91.88-.91 2.16s.93 2.51 1.06 2.69c.13.17 1.83 2.92 4.44 3.99.62.27 1.1.43 1.48.55.62.2 1.19.17 1.64.1.5-.07 1.54-.63 1.76-1.24.22-.61.22-1.13.15-1.24-.06-.11-.24-.18-.5-.31z`})})})]})]})}export{a as n,d as t};